let num1 = 15
let num2 = 23

if (num1 > num2) {
    console.log(num1 - num2)
} else {
    console.log(num2 - num1)
}

// console.log(Math.abs(num1 - num2))