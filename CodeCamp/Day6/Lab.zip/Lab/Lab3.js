//ex1

let a = 5
let b = 8
let c = 7

if (a >= b && a >= c) {
    console.log("Example 1 : " + a + "," + b + "," + c + " เลขที่มากที่สุด คือ " + a)
} else if (b >= a && b >= c) {
    console.log("Example 1 : " + a + "," + b + "," + c + " เลขที่มากที่สุด คือ " + b)
} else {
    console.log("Example 1 : " + a + "," + b + "," + c + " เลขที่มากที่สุด คือ " + c)
}

//ex2

let d = 9
let e = 8
let f = 7

if (d >= e && d >= f) {
    console.log("Example 2 : " + d + "," + e + "," + f + " เลขที่มากที่สุด คือ " + d)
} else if (e >= d && e >= f) {
    console.log("Example 2 : " + d + "," + e + "," + f + " เลขที่มากที่สุด คือ " + e)
} else {
    console.log("Example 2 : " + d + "," + e + "," + f + " เลขที่มากที่สุด คือ " + f)
}