let input = 4
let output = input.toString(2)

console.log(output)

let output2 = parseInt(output, 2)
console.log(output2.toString())
//
// let input
// let sum = 0
// for (let i = 0; i < input.) {

// }